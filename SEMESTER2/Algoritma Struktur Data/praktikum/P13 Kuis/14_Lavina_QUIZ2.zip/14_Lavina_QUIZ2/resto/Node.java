package resto;

public class Node {
  Node prev, next;

  Node(Node prev, Node next) {
    this.prev = prev;
    this.next = next;
  }
}
